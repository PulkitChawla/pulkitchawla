export const apiEndPoint = 'http://localhost:8081';
