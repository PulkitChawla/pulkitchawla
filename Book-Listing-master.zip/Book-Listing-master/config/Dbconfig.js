module.exports = function dbConnectionDetails(){
	return { 
	host: 'localhost',
	user: 'sadmin',
	password: 'twyla@123#',
	database: 'book_panel',
};
}